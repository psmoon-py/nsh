"""
Test ACM with a DELIBERATE collision scenario.

This script injects a debris object on a direct collision course
with one of your satellites, then steps forward and verifies:
  1. Conjunction IS detected (CDM warning appears)
  2. Evasion maneuver IS scheduled automatically
  3. Maneuver IS executed (fuel decreases)
  4. Collision IS avoided (0 collisions)
  5. Recovery burn IS scheduled (satellite returns to slot)

THIS IS THE SCRIPT THAT PROVES YOUR SOLUTION WORKS.

USAGE:
  1. Start your backend:  python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
  2. Run this script:     python scripts/test_collision_scenario.py

REQUIRES:
  pip install requests
"""

import requests
import json
import math
import sys
import time

API_BASE = "http://localhost:8000"
MU = 398600.4418  # km³/s²
RE = 6378.137     # km


def check_api():
    try:
        r = requests.get(f"{API_BASE}/api/visualization/snapshot", timeout=5)
        return r.status_code == 200
    except:
        return False


def get_snapshot():
    return requests.get(f"{API_BASE}/api/visualization/snapshot", timeout=10).json()


def advance(step_seconds):
    return requests.post(
        f"{API_BASE}/api/simulate/step",
        json={"step_seconds": step_seconds},
        timeout=60
    ).json()


def send_telemetry(timestamp, objects):
    return requests.post(
        f"{API_BASE}/api/telemetry",
        json={"timestamp": timestamp, "objects": objects},
        timeout=60
    ).json()


def run_test():
    print("=" * 70)
    print("  PROJECT AETHER — Collision Scenario Test")
    print("  This test PROVES your evasion system works")
    print("=" * 70)

    # ── Step 0: Check API ──
    print("\n[0] Checking API...")
    if not check_api():
        print("  ERROR: API not running. Start with:")
        print("  python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000")
        sys.exit(1)
    print("  API OK")

    # ── Step 1: Get initial state ──
    print("\n[1] Getting initial state...")
    snap = get_snapshot()
    print(f"  Satellites: {len(snap['satellites'])}")
    print(f"  Debris: {len(snap['debris_cloud'])}")
    print(f"  Timestamp: {snap['timestamp']}")

    if not snap['satellites']:
        print("  ERROR: No satellites loaded. Run: python scripts/generate_initial_data.py")
        sys.exit(1)

    # Pick the first satellite as our target
    target_sat = snap['satellites'][0]
    sat_id = target_sat['id']
    initial_fuel = target_sat['fuel_kg']
    print(f"\n  Target satellite: {sat_id}")
    print(f"  Position: ({target_sat['r']['x']:.1f}, {target_sat['r']['y']:.1f}, {target_sat['r']['z']:.1f}) km")
    print(f"  Fuel: {initial_fuel} kg")

    # ── Step 2: Advance a bit first to establish baseline ──
    print("\n[2] Advancing 1 minute to establish baseline...")
    result = advance(60)
    print(f"  Result: {result['status']}, collisions={result['collisions_detected']}, maneuvers={result['maneuvers_executed']}")

    snap = get_snapshot()
    target_sat = next(s for s in snap['satellites'] if s['id'] == sat_id)

    # ── Step 3: Create a debris object on COLLISION COURSE ──
    print("\n[3] Injecting debris on collision course...")

    # Get satellite's current position
    sat_r = target_sat['r']
    sat_pos = [sat_r['x'], sat_r['y'], sat_r['z']]
    r_mag = math.sqrt(sat_pos[0]**2 + sat_pos[1]**2 + sat_pos[2]**2)
    alt = r_mag - RE

    # Place debris 200km ahead in the satellite's orbit (same altitude, slightly offset)
    # Create a converging trajectory — debris moves TOWARD the satellite
    r_hat = [p / r_mag for p in sat_pos]

    # Debris at same radius, offset by 200km along-track
    # Use a perpendicular direction in the orbital plane
    perp = [-sat_pos[1], sat_pos[0], 0]
    perp_mag = math.sqrt(perp[0]**2 + perp[1]**2)
    if perp_mag > 0:
        perp = [p / perp_mag for p in perp]
    else:
        perp = [0, 1, 0]

    # Place debris 150km ahead
    offset_km = 150.0
    deb_pos = [
        sat_pos[0] + perp[0] * offset_km,
        sat_pos[1] + perp[1] * offset_km,
        sat_pos[2] + perp[2] * offset_km,
    ]

    # Give debris velocity pointing TOWARD the satellite (converging)
    v_circ = math.sqrt(MU / r_mag)  # circular velocity ~7.6 km/s
    # Debris velocity: circular + small component toward satellite
    deb_vel = [
        -perp[0] * v_circ * 0.02 + (-perp[1]) * v_circ,  # mostly along-track in opposite direction
        -perp[1] * v_circ * 0.02 + (perp[0]) * v_circ,
        0.0,
    ]

    # Actually, simpler: just put debris at same orbit but COUNTER-ORBITAL
    # This guarantees a collision in about offset_km / (2*v_circ) seconds
    deb_vel = [
        perp[0] * (-v_circ) + r_hat[0] * 0.0,
        perp[1] * (-v_circ) + r_hat[1] * 0.0,
        perp[2] * (-v_circ) + r_hat[2] * 0.0,
    ]

    collision_debris = {
        "id": "DEB-COLLISION-TEST",
        "type": "DEBRIS",
        "r": {"x": round(deb_pos[0], 6), "y": round(deb_pos[1], 6), "z": round(deb_pos[2], 6)},
        "v": {"x": round(deb_vel[0], 6), "y": round(deb_vel[1], 6), "z": round(deb_vel[2], 6)},
    }

    closing_speed = 2 * v_circ  # ~15.2 km/s head-on
    time_to_collision = offset_km / closing_speed  # ~9.8 seconds!

    print(f"  Debris position: ({deb_pos[0]:.1f}, {deb_pos[1]:.1f}, {deb_pos[2]:.1f}) km")
    print(f"  Offset from satellite: {offset_km} km")
    print(f"  Closing speed: ~{closing_speed:.1f} km/s (head-on counter-orbital)")
    print(f"  Estimated time to collision: ~{time_to_collision:.1f} seconds")

    # Send the debris via telemetry
    result = send_telemetry(snap['timestamp'], [collision_debris])
    print(f"  Telemetry response: {json.dumps(result)}")
    print(f"  CDM warnings after injection: {result.get('active_cdm_warnings', 0)}")

    # ── Step 4: Check if conjunction was detected ──
    print("\n[4] Checking conjunction detection...")
    snap = get_snapshot()
    cdms = snap.get('cdm_warnings', [])
    queue = snap.get('maneuver_queue', [])

    print(f"  CDM Warnings: {len(cdms)}")
    for cdm in cdms[:5]:
        print(f"    {cdm['sat_id']} ↔ {cdm['deb_id']} | TCA: {cdm['tca_seconds']:.0f}s | Miss: {cdm['miss_distance_km']:.4f}km | {cdm['risk_level']}")

    print(f"  Maneuver Queue: {len(queue)}")
    for m in queue[:5]:
        print(f"    {m['sat_id']} | {m['burn_type']} | ΔV: {m['dv_magnitude_ms']:.2f} m/s | {m['burn_time']}")

    if len(cdms) > 0:
        print("  ✅ CONJUNCTION DETECTED!")
    else:
        print("  ⚠️  No conjunction detected yet (may appear after propagation)")

    if len(queue) > 0:
        print("  ✅ EVASION MANEUVER SCHEDULED!")
    else:
        print("  ⚠️  No maneuver scheduled yet")

    # ── Step 5: Advance simulation to trigger evasion ──
    print("\n[5] Advancing simulation (10s steps × 20)...")
    total_maneuvers = 0
    total_collisions = 0

    for i in range(20):
        result = advance(10)
        man = result.get('maneuvers_executed', 0)
        col = result.get('collisions_detected', 0)
        total_maneuvers += man
        total_collisions += col
        if man > 0 or col > 0:
            print(f"  Step {i+1}: maneuvers={man}, collisions={col}")

    # ── Step 6: Check results ──
    print("\n[6] Results after short-term propagation...")
    snap = get_snapshot()
    target_sat = next((s for s in snap['satellites'] if s['id'] == sat_id), None)

    if target_sat:
        fuel_now = target_sat['fuel_kg']
        fuel_used = initial_fuel - fuel_now
        print(f"  Fuel before: {initial_fuel:.2f} kg")
        print(f"  Fuel after:  {fuel_now:.2f} kg")
        print(f"  Fuel consumed: {fuel_used:.4f} kg")
        print(f"  Status: {target_sat['status']}")
    
    print(f"  Total maneuvers executed: {total_maneuvers}")
    print(f"  Total collisions: {total_collisions}")

    # ── Step 7: Continue propagation for longer-term test ──
    print("\n[7] Long-term propagation (1-hour steps × 24 = 24h)...")
    for i in range(24):
        result = advance(3600)
        man = result.get('maneuvers_executed', 0)
        col = result.get('collisions_detected', 0)
        total_maneuvers += man
        total_collisions += col
        if man > 0 or col > 0:
            snap_now = get_snapshot()
            print(f"  Hour {i+1}: maneuvers={man}, collisions={col}, CDMs={len(snap_now.get('cdm_warnings', []))}")

    # ── Step 8: Final assessment ──
    print("\n" + "=" * 70)
    print("  FINAL ASSESSMENT")
    print("=" * 70)

    snap = get_snapshot()
    target_sat = next((s for s in snap['satellites'] if s['id'] == sat_id), None)
    sats = snap.get('satellites', [])

    nominal_count = sum(1 for s in sats if s.get('status') == 'NOMINAL')
    total_fuel = sum(s.get('fuel_kg', 0) for s in sats)

    print(f"\n  Simulation time: {snap['timestamp']}")
    print(f"  Collisions: {total_collisions}")
    print(f"  Maneuvers executed: {total_maneuvers}")
    print(f"  NOMINAL satellites: {nominal_count}/{len(sats)}")
    print(f"  Fleet fuel: {total_fuel:.1f} kg / {50.0*len(sats):.0f} kg")
    print(f"  Fleet uptime: {snap.get('fleet_uptime', 'N/A')}")

    if target_sat:
        print(f"\n  Target {sat_id}:")
        print(f"    Fuel: {target_sat['fuel_kg']:.2f} kg (consumed {initial_fuel - target_sat['fuel_kg']:.4f} kg)")
        print(f"    Status: {target_sat['status']}")

    # Verdict
    print("\n  ── VERDICT ──")
    passed = True

    if total_collisions == 0:
        print("  ✅ PASS: Zero collisions (25% Safety Score)")
    else:
        print(f"  ❌ FAIL: {total_collisions} collision(s) occurred")
        passed = False

    if total_maneuvers > 0:
        print(f"  ✅ PASS: {total_maneuvers} autonomous maneuver(s) executed")
    else:
        print("  ❌ FAIL: No maneuvers executed — evasion system did not trigger")
        passed = False

    if target_sat and target_sat['fuel_kg'] < initial_fuel:
        print("  ✅ PASS: Fuel tracking works (Tsiolkovsky equation)")
    else:
        print("  ⚠️  WARN: No fuel consumed — check maneuver execution")

    if nominal_count > 0:
        print(f"  ✅ PASS: {nominal_count} satellites maintaining slot (15% Uptime Score)")
    else:
        print("  ⚠️  WARN: All satellites OUT_OF_SLOT")

    if passed:
        print("\n  ══ ALL CRITICAL TESTS PASSED ══")
    else:
        print("\n  ══ SOME TESTS FAILED — review above ══")

    print()


if __name__ == "__main__":
    run_test()
